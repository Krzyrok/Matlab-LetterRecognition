%Task 2A 
clear all 
close all 
clc
load digits.mat
%plotting the original (correct) digits 
figure; 
title('original digits'); 
colormap([1 1 1;0 0 0]) 
 subplot(2,4,1),imagesc(digits(:,:,1));
 title('Digit:"0"'); 
 subplot(2,4,2),imagesc(digits(:,:,2)); 
 title('Digit:"1"');
 subplot(2,4,3),imagesc(digits(:,:,3));
 title('Digit:"2"');
 subplot(2,4,4),imagesc(digits(:,:,4));
 title('Digit:"3"');
 subplot(2,4,5),imagesc(digits(:,:,5));
 title('Digit:"4"');
 subplot(2,4,6),imagesc(digits(:,:,6)); 
 title('Digit:"6"');
 subplot(2,4,7),imagesc(digits(:,:,7));
 title('Digit:"\prime"'); 
 subplot(2,4,8),imagesc(digits(:,:,8));
 title('Digit:"9"');
%creating the input matrix
X=zeros(120,8);
for i=1:8 x_temp=digits(:,:,i);
    X(:,i)=x_temp(:);
end
%%%%%%%%%%%%%%%%%%Using Hebbian paradigm%%%%%%%%%%%%%%%% %creating auto-associative memory using Hebbian paradigm
W=X*(X');
%processing through the neural network for distorted digits 
Y=zeros(120,6);
for j=1:6 
    x_temp=distorted_digits(:,:,j);
    Y(:,j)=sign(W*x_temp(:));
end
%plotting reconstructed digits 
figure;
colormap([1 1 1;0 0 0]) 
subplot(2,3,1),imagesc(reshape(Y(:,1),12,10));
title('Digit:"0"'); 
subplot(2,3,2),imagesc(reshape(Y(:,2),12,10));
title('Digit:"1"'); 
subplot(2,3,3),imagesc(reshape(Y(:,3),12,10));
title('Digit:"2"'); 
subplot(2,3,4),imagesc(reshape(Y(:,4),12,10)); 
title('Digit:"3"'); 
subplot(2,3,5),imagesc(reshape(Y(:,5),12,10));
title('Digit:"4"'); 
subplot(2,3,6),imagesc(reshape(Y(:,6),12,10)); title('Digit:"\prime"');
%%%%%%%%%%%%%%%%%%Using pseudoinverse%%%%%%%%%%%%%%%% %creating auto-associative memory using pseudoinverse 
W=X*pinv(X);
%processing through the neural network for distorted digits
Y=zeros(120,6);
for j=1:6 
    x_temp=distorted_digits(:,:,j);
    Y(:,j)=sign(W*x_temp(:));
end
%plotting reconstructed digits 
figure;
colormap([1 1 1;0 0 0]) 
subplot(2,3,1),imagesc(reshape(Y(:,1),12,10));
title('Digit:"0"'); 
subplot(2,3,2),imagesc(reshape(Y(:,2),12,10));
title('Digit:"1"'); 
subplot(2,3,3),imagesc(reshape(Y(:,3),12,10)); 
title('Digit:"2"'); 
subplot(2,3,4),imagesc(reshape(Y(:,4),12,10));
title('Digit:"3"');
subplot(2,3,5),imagesc(reshape(Y(:,5),12,10));
title('Digit:"4"');
subplot(2,3,6),imagesc(reshape(Y(:,6),12,10));
title('Digit:"\prime"');